<div id="f_title">
	<h1><?php echo strtoupper(SITE_NAME); ?> ADMIN Panel</h1>
</div>

