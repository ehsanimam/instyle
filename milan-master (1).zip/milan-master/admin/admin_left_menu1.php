<table width="100%">
  <!--DWLayoutTable-->
      <tr>
         <td width="3%" valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
         <td width="97%" valign="middle"><a href='change_password.php' class="common">Change Administrator Password</a></td>
      </tr>
	  <tr>
         <td width="3%" valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
         
    <td width="97%" valign="middle"><a href='index_manage.php' class="common">Index 
      Page Management</a></td>
      </tr>
	   <tr>
        <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
        <td valign="middle"><span class="head">User Management</span></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>        
   		<td><a href="upload-user.php" class="common">Add User Throw CSV</a></td>
      </tr>
	   <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>        
   		<td><a href="add_user.php" class="common">Add User</a> || <a href="edit_user.php" class="common">User Maintenance</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>        
   		<td><a href="login_detail.php" class="common">Login Details</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
        <td valign="middle"><span class="head">Home Menu Management</span></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        
    <td valign="middle"><a href="news.php" class="common">Add News</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        
    <td valign="middle"><a href="news_details.php" class="common">View/Edit News</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="contact.php" class="common">Add/Edit Links </a></td>
      </tr>
	     <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="legal.php" class="common">Add/Edit Legal</a></td>
      </tr>
	   </tr>
	     <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_press.php" class="common">Add Press</a><a href="edit_collection.php" class="common"><span class="head"> || </span> Edit/Delete Press</a></td>
      </tr>
	   </tr>
	     <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_contract.php" class="common">Add Contract</a><a href="edit_contract.php" class="common"><span class="head"> || </span> Edit/Delete Contract</a></td>
      </tr>
      <tr>
        <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
        <td valign="middle"><span class="head">Category Management</span></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_category.php" class="common">Add  Category</a><span class="head"> || </span>
                      <a href="edit_category.php" class="common">Edit/Delete Category</a></li></td>
      </tr>
      <!--<tr>
        <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
        <td valign="middle"><span class="head">Subcategory Management</span></td>
      </tr>-->
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_subcategory.php" class="common">Add Sub Category</a><span class="head"> || </span>
                      <a href="edit_subcategory.php" class="common">Edit/Delete Sub Category</a></li></td>
      </tr>
	  <!-- <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_subtypecategory.php" class="common">Add Sub Type Category</a><span class="head"> || </span>
                      <a href="edit_subtypecategory.php" class="common">Edit/Delete Sub Type Category</a></li></td>
      </tr> -->
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_typecategory.php" class="common">Add Type Category</a><span class="head"> || </span>
                      <a href="edit_typecategory.php" class="common">Edit/Delete Type Category</a></li></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_typeheading.php" class="common">Add Type Heading</a><span class="head"> || </span>
                      <a href="edit_typeheading.php" class="common">Edit/Delete Type Heading</a></li></td>
      </tr>
      <!--<tr>
        <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
        <td valign="middle"><span class="head">Manufacturer Management</span></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_manufacturer.php" class="common">Add Manufacturer</a><span class="head"> || </span>
                      <a href="edit_manufacturer.php" class="common">Edit/Delete Manufacturer</a></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_sub_manufacturer.php" class="common">Add Sub Category</a><span class="head"> || </span>
                      <a href="edit_sub_manufacturer.php" class="common">Edit/Delete Sub Category</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="bullet.gif" alt=" "></td>
        <td valign="middle"><span class="head">Trend Management</span></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_trend.php" class="common">Add Trend</a><span class="head"> || </span>
                      <a href="edit_trend.php" class="common">Edit/Delete Trend</a></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_sub_trend.php" class="common">Add Sub Category</a><span class="head"> || </span>
                      <a href="edit_sub_trend.php" class="common">Edit/Delete Sub Category</a></td>
      </tr>
      <tr>-->
        <td valign="top"><img src="bullet.gif" alt=" "></td>
        <td valign="middle"><span class="head">Product Management</span></td>
      </tr>
	   <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="addnew_product.php" class="common">Add New Product</a><span class="head"> || </span>
                      <a href="display_new_product.php" class="common">Edit/Delete New Product</a></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_product.php" class="common">Add Product</a><span class="head"> || </span>
                      <a href="display_product.php" class="common">Edit/Delete Product</a></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_det_product_2.php?acts=1" class="common">Add Details to Product</a><span class="head"> || </span>
                      <a href="edit_det_product.php" class="common">Edit/Delete Details</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_det_product_chandeliers.php?acts=1" class="common">Add / Edit Details to CHANDELIERS</a><!--<span class="head"> || </span>
                      <a href="edit_det_product.php" class="common">Edit/Delete Details</a>--></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_size_product.php" class="common">Add Size & color</a><span class="head"> || </span>
                      <a href="edit_size_product.php" class="common">Edit/Delete Size & color</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_dimension_price.php" class="common">Add Dimension Price</a> <span class="head"> || </span>
                      <a href="edit_dimension_price.php" class="common">Edit Dimension</a></td>
      </tr>
	 
      <tr>
        <td valign="top"><img src="bullet.gif" alt=" "></td>
        <td valign="middle"><span class="head">Color Management</span></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_color.php" class="common">Add Color</a><span class="head"> || </span>
                      <a href="edit_color.php" class="common">Edit/Delete Color</a></td>
      </tr>
      <tr>
        <td valign="top"><img src="bullet.gif" alt=" "></td>
        <td valign="middle"><span class="head">Size Management</span></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_size.php" class="common">Add Size</a><span class="head"> || </span>
                      <a href="edit_size.php" class="common">Edit/Delete Size</a></td>
      </tr>
      <!--<tr>
        <td valign="top"><img src="bullet.gif" alt=" "></td>
        <td valign="middle"><a href="order_display.php" class="common">View Order History</a></td>
      </tr>
      <tr>
        <td valign="top"><img src="bullet.gif" alt=" "></td>
        <td valign="middle"><a href='edit_index.php' class="common">Edit Index Page</a></td>
      </tr>-->
	  <tr>
        <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
        <td valign="middle"><span class="head">About Instyle New York</span></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="press.php" class="common">Add/Edit Press</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="vision.php" class="common">Add/Edit Our Vision</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="location.php" class="common">Add/Edit Locations</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="event.php" class="common">Add/Edit Events</a></td>
      </tr>
      <tr>
        <td valign="top"><img src="bullet.gif" alt=" "></td>
        <td valign="middle"><a href="logout.php" class="common">Log Out</a></td>
      </tr>      
</table>
