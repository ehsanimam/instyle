<? 
include("../common.php");
include("security.php");
include 'top.php'; 
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
<tr>
	<td height="333" class="tab" align="center"><h1>Welcome, Administrator
                       <br>View Left Navigation Menu For Site Administration</h1></td>
</tr>
</table>
<? //include 'footer.php'; ?>