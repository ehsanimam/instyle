<table width="100%">
  <!--DWLayoutTable-->
      <tr>
         <td width="3%" valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
         <td width="97%" valign="middle"><a href='change_password.php' class="common">Change Administrator Password</a></td>
      </tr>
	  <tr>
         <td width="3%" valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
         
    <td width="97%" valign="middle"><a href='index_manage.php' class="common">Index 
      Page Management</a></td>
      </tr>
	  	  <tr>
         <td width="3%" valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
		<td width="97%" valign="middle"><a href='opt_in_list.php' class="common">OPT IN LIST</a></td>
      </tr>
	<tr>
        <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
        <td valign="middle"><span class="head">Meta Management</span></td>
      </tr>
		<tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="mdata.php" class="common">Add Meta</a><a href="mdata_details.php" class="common"><span class="head"> || </span> Edit/Delete Meta</a></td>
      </tr>

	   <tr>
        <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
        <td valign="middle"><span class="head">User Management</span></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>        
   		<td><a href="upload-user.php" class="common">Add Users Using CSV Upload File</a></td>
      </tr>
	   <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>        
   		<td><a href="add_user.php" class="common">Add User</a> || <a href="edit_user.php" class="common">User Maintenance</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>        
   		<td><a href="login_detail.php" class="common">Login Details</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>        
   		<td><a href="contact_list.php" class="common">Contact Details</a></td>
      </tr>
	  <tr>
	    <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22" /></td>
	    <td><span class="head">Index Rotation  Management</span></td>
  </tr>
	  <tr>
	    <td valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
	    <td><a href="add_index.php" class="common">Add/Edit Image</a> </td>
  </tr>
   <tr>
	    <td valign="top"><!--DWLayoutEmptyCell-->&nbsp;</td>
	    <td><a href="add_video.php" class="common">Add/Edit Video</a> </td>
  </tr>
	  <tr>
        <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
        <td valign="middle"><span class="head">Home Menu Management</span></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        
    <td valign="middle"><a href="news.php" class="common">Add News</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        
    <td valign="middle"><a href="news_details.php" class="common">View/Edit News</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="contact.php" class="common">Add/Edit Links </a></td>
      </tr>
	     <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="legal.php" class="common">Add/Edit Legal</a></td>
      </tr>
	   </tr>
	    
	   </tr>
  <tr>
        <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
        <td valign="middle"><span class="head">Facet Management</span></td>
      </tr>
     
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_event.php" class="common">Add Event Facet</a><span class="head"> || </span>
                      <a href="edit_event.php" class="common">Edit Event Facet</a></li></td>
      </tr>	   
	  
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_style.php" class="common">Add Styling Facet</a><span class="head"> || </span>
                      <a href="edit_style.php" class="common">Edit Styling Facet</a></li></td>
      </tr>	  
	  
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_color_facet.php" class="common">Add Color Alias Facet</a><span class="head"> || </span>
                      <a href="edit_color_facet.php" class="common">Edit Color Alias Facet</a></li></td>
      </tr>	 
	  
	   <tr>
        <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
        <td valign="middle"><span class="head">Category Management</span></td>
      </tr>
     
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_category.php" class="common">Add  Category</a><span class="head"> || </span>
                      <a href="edit_category.php" class="common">Edit/Delete Category</a></li></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_subcategory.php" class="common">Add Sub Category</a><span class="head"> || </span>
                      <a href="edit_subcategory.php" class="common">Edit/Delete Sub Category</a></li></td>
      </tr>
       <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_subsubcategory.php" class="common">Add Sub Sub Category</a><span class="head"> || </span>
                      <a href="edit_subsubcategory.php" class="common">Edit/Delete Sub Sub Category</a></li></td>
      </tr>
      <!-- <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_typeheading.php" class="common">Add Type Category</a><span class="head"> || </span>
                      <a href="edit_typeheading.php" class="common">Edit/Delete Type Category</a></li></td>
      </tr>
       <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_typecategory.php" class="common">Add Type Sub Category</a><span class="head"> || </span>
                      <a href="edit_typecategory.php" class="common">Edit/Delete Type Sub Category</a></li></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_typesubcategory.php" class="common">Add Type Sub Sub Category</a><span class="head"> || </span>
                      <a href="edit_typesubcategory.php" class="common">Edit/Delete Type Sub Sub Category</a></li></td>
      </tr>-->
	<tr>   
        <td valign="top"><img src="bullet.gif" alt=" "></td>
        <td valign="middle"><span class="head">Designer Management</span></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_designer.php" class="common">Add Designer</a><span class="head"> || </span>
                      <a href="edit_designer.php" class="common">Edit/Delete Designer</a></li></td>
      </tr> 
	 <!-- <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_designer_type.php" class="common">Add Designer Type</a><span class="head"> || </span>
                      <a href="edit_designer_type.php" class="common">Edit/Delete Designer Type</a></li></td>
      </tr> --> 
	  <tr>   
        <td valign="top"><img src="bullet.gif" alt=" "></td>
        <td valign="middle"><span class="head">Product Management</span></td>
      </tr>
       <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>        
   		<td><a href="upload-product.php" class="common">Load CSV [ product data ]</a></td>
      </tr>
	   <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="addnew_product.php" class="common">Add New Product</a> /
                      <a href="display_new_product.php" class="common">Edit/Delete Product</a></td>
      </tr>
      <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="addnew_bridalproduct.php" class="common">Add New Bridal Product</a> /
                      <a href="display_product_new.php?catid=22" class="common">Edit/Delete Bridal Product</a></td>
      </tr>  
       <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>        
   		<td><a href="upload-stock.php" class="common">Load CSV [ product stock ]</a></td>
      </tr>
       <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_color_size.php" class="common">Edit Stock</a> </li></td>
      </tr>  
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="upload_designer_stock.php" class="common">Edit Designer Stock throw CSV</a> </li></td>
      </tr>     
       <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_color.php" class="common">Add Color</a> /
                      <a href="edit_color.php" class="common">Edit/Delete Color</a></li></td>
      </tr>
       <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_newsize.php" class="common">Add Size</a> /
                      <a href="edit_newsize.php" class="common">Edit/Delete Size</a></li></td>
      </tr>
       <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_size.php" class="common">Color Size Management</a> </li></td>
      </tr>
		<?php
		/*
		|--------------------------------------------------------------------
		|
		| Added this line item as link for options to view Order logs in the
		| admin panel
		*/
		?>
       <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="order_log.php" class="common">Order Logs</a> </li></td>
      </tr>  
		<?php
		/*
		|--------------------------------------------------------------------
		*/
		?>
     <!--<tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="add_size.php" class="common">Upload New CSV</a> /
                      <a href="edit_cs.php" class="common">Update Existing CSV</a></li></td>
      </tr>-->
	  <tr>
        <td valign="top"><img src="bullet.gif" alt=" " width="24" height="22"></td>
        <td valign="middle"><span class="head">About Instyle Newyork</span></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="press.php" class="common">Add/Edit Press</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="vision.php" class="common">Add/Edit Our Vision</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="location.php" class="common">Add/Edit Locations</a></td>
      </tr>
	  <tr>
        <td valign="top"><img src="spacer.gif" alt=" " width="1" height="18"></td>
        <td valign="middle"><a href="event.php" class="common">Add/Edit Events</a></td>
      </tr>
      <tr>
        <td valign="top"><img src="bullet.gif" alt=" "></td>
        <td valign="middle"><a href="logout.php" class="common">Log Out</a></td>
      </tr>      
</table>
