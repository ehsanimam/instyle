<?
session_start();
include("../common.php");
include('../functionsadmin.php');
include 'top.php'; 
?>
<table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#FFFFFF">
<tr>
	<td height="333" class="tab" align="center" valign="middle">
	
	
	
	
	
	</td>
</tr>
</table>
<? include 'footer.php'; ?>