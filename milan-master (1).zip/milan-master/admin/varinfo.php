<?php
	include("../common.php");

	echo $db;
	echo '<br />';
	echo $db_remote;
	echo '<br />';
	