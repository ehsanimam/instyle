<?php
	include("../common.php");
	include("../../z-temp-1.php");

	echo $test;