<?php

include_once('noca.php');
include_once('rcq.php');

?>

<HTML>
<HEAD>
<meta http-equiv=Content-Type content="text/html;  charset=ISO-8859-1">
<TITLE>Status Imahe</TITLE>
</HEAD>
<BODY>

<h3>Flash based status indicator:</h3>
<?php
	echo phpOnlineGetFlashCode('status');
?>

<h3>Image based status indicator:</h3>
<a href="client.php" target="_blank"><img border="0" src="statusimage.php?rn=<?php echo rand(1000,9999);?>" width="122" height="62"></a>

</BODY>
</HTML>