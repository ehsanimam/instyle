<?php
/*********************************
phpOnline Language Strings
Deutsch
*********************************/
$LANG = array();

$LANG[1]  = "Bitte warten...";
$LANG[2]  = "Es wird ein freier Kundendienst Mitarbeiter gesucht.";
$LANG[3]  = "Saemtliche Kundendienst Mitarbeiter sind zur Zeit besetzt. Bitte versuchen Sie es spaeter nochmals oder hinterlassen Sie uns eine Mitteilung:";
$LANG[4]  = "Willkommen zum ".str_replace("www.","",$_SERVER["HTTP_HOST"])." Online Support.";
$LANG[5]  = "Nachricht senden";
$LANG[6]  = "Danke";
$LANG[7]  = "Einer unserer Kundendienst Mitarbeiter wird Sie in Kuerze kontaktieren.";
$LANG[8]  = "Leider koennen wir Ihre Nachricht nicht uebermitteln.\nBitte senden Sie uns direkt an unsere Email Adresse eine Nachricht\nund entschuldigen Sie die Umtriebe.";
$LANG[9]  = "Benutzername";
$LANG[10] = "Passwort";
$LANG[11] = "Sprache";
$LANG[12] = "Anmelden";
$LANG[13] = "Falscher Benutzername und/oder Passwort";
$LANG[14] = "Benutzername und Passwort ueberprueft.";
$LANG[15] = "Abmelden";
$LANG[16] = "News";
$LANG[17] = "Einstellungen";
$LANG[18] = "Online";
$LANG[19] = "Kunden die auf Hilfe warten";
$LANG[20] = "Netzwerk Aktivitaet";
$LANG[21] = "Wartende Benutzer";
$LANG[22] = "Benutzer Online";
$LANG[23] = "Neuheiten und Bekanntmachungen";
$LANG[24] = "Einstellungen und Konfigurationen";
$LANG[25] = "Generell";
$LANG[26] = "Texte";
$LANG[27] = "Mitarbeiter";
$LANG[28] = "Lizenz";
$LANG[29] = "Firmenname";
$LANG[30] = "Domaenenname";
$LANG[31] = "Email Adresse";
$LANG[32] = "Email Betreff";
$LANG[33] = "Warten auf Mitarbeiter";
$LANG[34] = "Sekunden";
$LANG[35] = "Sprachauswahl anzeigen";
$LANG[36] = "Speichern";
$LANG[37] = "Laden";
$LANG[38] = "Texte und Sprachen";
$LANG[39] = "Falls Sie von uns eine Lizenz gekauft haben geben Sie sie hier ein.";
$LANG[40] = "Neu";
$LANG[41] = "Update";
$LANG[42] = "Loeschen";
$LANG[43] = "Power User";
$LANG[44] = "Zugang nur fuer Power User gestattet.";
$LANG[45] = "Konfiguration gespeichert.";
$LANG[46] = "Antworten";
$LANG[47] = "Ablehnen";
$LANG[48] = "Schliessen";
$LANG[49] = "Spitzname";
$LANG[50] = "LOS";
$LANG[51] = "SENDEN";
$LANG[52] = "Admin schreibt ...";
$LANG[53] = "Warteschlange, bitte warten ...";
$LANG[54] = "Live Kunden Support System";
$LANG[55] = "Ihr Name";
$LANG[56] = "Email Adresse";
$LANG[57] = "Nachricht";
$LANG[58] = "NACHRICHT HINTERLASSEN";
$LANG[59] = "Sie wurden einem Kundendienst Mitarbeiter zugewiesen, aber er ist gerade beschaeftigt. Bitte warten. Danke fuer Ihre Geduld.";
$LANG[60] = "Sie koennen den Aufruf loeschen und eine Nachricht hinterlassen.";
$LANG[61] = "Halten";
$LANG[62] = "Holen";
$LANG[63] = "Warteschlange";
$LANG[64] = "Beenden";
$LANG[65] = "Protokoll senden";
$LANG[66] = "Noch online?";
$LANG[67] = "Absender";
$LANG[68] = "Empfaenger";
$LANG[69] = "Loeschen";
$LANG[70] = "Senden";
$LANG[71] = "Nein";
$LANG[72] = "Ja";
$LANG[73] = "Erledigt";
$LANG[74] = "Fehler beim Uebermitteln des Chat Protokolls";
$LANG[75] = "Kunden Email Adresse ermitteln";
$LANG[76] = "IP Adresse";
$LANG[77] = "Email";
$LANG[78] = "In Konversation mit";
$LANG[79] = "Kunde";
$LANG[80] = "Kunde ist wartend";
$LANG[81] = "Kunde ist nicht mehr wartend";
$LANG[82] = "Kunde ist immer noch online";
$LANG[83] = "Verbindung geschlossen";
$LANG[84] = "Kunde schreibt...";
$LANG[85] = "Sie";
$LANG[86] = "Verbunden mit";
$LANG[87] = "Von rechts nach links schreiben";
$LANG[88] = "Email in Klartext senden";
$LANG[89] = "Verbindungsfehler";
$LANG[90] = "Keine Lizenz-Informationen anzeigen";
$LANG[91] = "�ndern Sie auf phpOnline";
$LANG[92] = "Ringe";
$LANG[93] = "Kunde Waiting";



?>
